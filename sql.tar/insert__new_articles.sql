use magasin;
insert into article values ('Chaussures pointure 45', 103);
insert into article values ('Chaussures pointure 38', 30);
insert into article values ('Chaussures pointure 39', 120);
insert into article values ('Chaussures pointure 40', 500);
