use magasin;
insert into article values ('Chaussures pointure 42', 10.50);
insert into article values ('Chaussures pointure 44', 15);
