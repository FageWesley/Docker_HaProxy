create database magasin;
use magasin;
create table article (description varchar(40), prix float);
